use std::fmt::Debug;

// ===== 泛型结构体 =====
#[derive(Debug)]
struct Pair<T> {
    first: T,
    second: T,
}

// ===== 泛型方法 =====
impl<T: Debug> Pair<T> {
    fn print(&self) {
        println!("Pair: {:?} and {:?}", self.first, self.second);
    }
}

// ===== 自定义 trait =====
trait Attack {
    fn attack(&self);
}

// ===== 为不同类型实现 trait =====
impl Attack for String {
    fn attack(&self) {
        println!("字符串 '{}' 发起攻击！", self);
    }
}

impl Attack for i32 {
    fn attack(&self) {
        println!("数字 {} 发起攻击！", self);
    }
}

impl<T: Debug> Attack for Pair<T> {
    fn attack(&self) {
        println!("Pair 发起攻击！内容是：{:?}", self);
    }
}

// ===== 用 impl Trait 接收实现了 Attack 的类型 =====
fn fire_weapon(item: impl Attack) {
    item.attack();
}

// ===== 生命周期标注：x 和 y 至少活得一样久 =====
fn longest<'a>(x: &'a String, y: &'a String) -> &'a String {
    if x.len() > y.len() {
        x
    } else {
        y
    }
}

// ===== 主函数 =====
fn main() {
    // 泛型结构体
    let pair1 = Pair { first: 10, second: 20 };
    let pair2 = Pair { first: String::from("守夜者"), second: String::from("燃烧者") };

    pair1.print();
    pair2.print();

    // trait 实现
    let name = String::from("守夜者");
    let number = 42;

    fire_weapon(name);
    fire_weapon(number);
    fire_weapon(pair1);

    // 生命周期
    let a = String::from("短");
    let b = String::from("长字符串");
    let longer = longest(&a, &b);
    println!("较长的是：{}", longer);
}