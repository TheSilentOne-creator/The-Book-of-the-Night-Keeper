use std::io::{BufRead, BufReader, Write};
use std::net::TcpListener;
use std::sync::mpsc;
use std::sync::Arc;
use std::sync::Mutex;
use std::thread;

/*运行，然后用并发脚本测试：

```bash
for i in {1..10}; do curl http://127.0.0.1:1234 & done
```

10 个请求，4 个工作线程轮流处理。终端会显示每个请求由哪个 Worker 处理。*/

type Job = Box<dyn FnOnce() + Send + 'static>;

struct ThreadPool {
    workers: Vec<Worker>,
    sender: mpsc::Sender<Job>,
}

impl ThreadPool {
    fn new(size: usize) -> ThreadPool {
        let (sender, receiver) = mpsc::channel();
        let receiver = Arc::new(Mutex::new(receiver));

        let mut workers = Vec::with_capacity(size);
        for id in 0..size {
            workers.push(Worker::new(id, Arc::clone(&receiver)));
        }

        ThreadPool { workers, sender }
    }

    fn execute<F>(&self, f: F)
    where
        F: FnOnce() + Send + 'static,
    {
        let job = Box::new(f);
        self.sender.send(job).unwrap();
    }
}

struct Worker {
    id: usize,
    thread: thread::JoinHandle<()>,
}

impl Worker {
    fn new(id: usize, receiver: Arc<Mutex<mpsc::Receiver<Job>>>) -> Worker {
        let thread = thread::spawn(move || loop {
            let job = receiver.lock().unwrap().recv().unwrap();
            println!("Worker {} 开始执行任务", id);
            job();
        });

        Worker { id, thread }
    }
}

// 从第11章复用的响应构建函数
fn build_http_response(status_line: &str, body: &str) -> String {
    format!(
        "{}\r\nContent-Length: {}\r\n\r\n{}\r\n",
        status_line,
        body.len(),
        body
    )
}

fn handle_connection(mut stream: std::net::TcpStream) {
    let reader = BufReader::new(&stream);
    let request_line = match reader.lines().next() {
        Some(Ok(line)) => line,
        _ => return,
    };
    println!("收到请求: {}", request_line);

    // 提取路径
    let path = request_line
        .split_whitespace()
        .nth(1)
        .unwrap_or("/");

    // 根据路径返回不同响应
    let (status, body) = match path {
        "/" => ("HTTP/1.1 200 OK", "Keeper is here."),
        "/status" => ("HTTP/1.1 200 OK", "Status: alive."),
        _ => ("HTTP/1.1 404 NOT FOUND", "Not found."),
    };

    let response = build_http_response(status, body);
    let _ = stream.write_all(response.as_bytes());
    let _ = stream.flush();
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let listener = TcpListener::bind("127.0.0.1:1234")?;
    let pool = ThreadPool::new(4);

    println!("守夜者已经站岗: http://127.0.0.1:1234");

    for stream in listener.incoming() {
        let stream = stream?;
        pool.execute(move || {
            handle_connection(stream);
        });
    }

    Ok(())
}