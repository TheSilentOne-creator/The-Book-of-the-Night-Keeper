use std::rc::Rc;
use std::cell::RefCell;

// ===== 弱点报告结构体 =====
#[derive(Debug, Clone)]
struct WeaknessReport {
    target: String,
    details: String,
    confirmed: bool,
}

impl WeaknessReport {
    fn new(target: &str, details: &str) -> Self {
        WeaknessReport {
            target: target.to_string(),
            details: details.to_string(),
            confirmed: false,
        }
    }

    fn confirm(&mut self) {
        self.confirmed = true;
        self.details.push_str(" [已确认]");
    }

    fn summary(&self) -> String {
        format!(
            "目标: {} | 详情: {} | 状态: {}",
            self.target,
            self.details,
            if self.confirmed { "已确认" } else { "待验证" }
        )
    }
}

// ===== 档案结构体（包含审计日志） =====
struct Archive {
    reports: Vec<WeaknessReport>,
    audit_log: Vec<String>,
}

impl Archive {
    fn new() -> Self {
        Archive {
            reports: Vec::new(),
            audit_log: Vec::new(),
        }
    }

    fn add(&mut self, report: WeaknessReport) {
        let msg = format!(
            "[{}] 添加报告: {}",
            Self::current_time(),
            report.target
        );
        self.audit_log.push(msg);
        self.reports.push(report);
    }

    fn remove(&mut self, target: &str) {
        let msg = format!(
            "[{}] 删除报告: {}",
            Self::current_time(),
            target
        );
        self.audit_log.push(msg);
        self.reports.retain(|r| r.target != target);
    }

    fn confirm_report(&mut self, target: &str) {
        for report in &mut self.reports {
            if report.target == target {
                report.confirm();
                let msg = format!(
                    "[{}] 确认报告: {}",
                    Self::current_time(),
                    target
                );
                self.audit_log.push(msg);
                break;
            }
        }
    }

    fn list(&self) -> Vec<String> {
        self.reports.iter().map(|r| r.summary()).collect()
    }

    fn audit_report(&self) -> Vec<String> {
        self.audit_log.clone()
    }

    fn current_time() -> String {
        use std::time::{SystemTime, UNIX_EPOCH};
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        format!("{}", now)
    }
}

// ===== 安全读取函数 =====
fn safe_read<F, T>(archive: &Rc<RefCell<Archive>>, f: F) -> T
where
    F: FnOnce(&Archive) -> T,
{
    let borrowed = archive.borrow();
    f(&borrowed)
}

// ===== 主函数 =====
fn main() {
    println!("=== 创建共享档案 ===\n");

    // 创建一份被 Rc<RefCell> 包裹的档案
    let archive = Rc::new(RefCell::new(Archive::new()));

    // 多位分析员共享同一份档案
    let analyst1 = Rc::clone(&archive);
    let analyst2 = Rc::clone(&archive);
    let analyst3 = Rc::clone(&archive);

    // 验证引用计数
    println!("初始引用计数: {}", Rc::strong_count(&archive));

    println!("\n=== 分析员1 添加报告 ===\n");

    // 分析员1 添加报告
    analyst1.borrow_mut().add(WeaknessReport::new(
        "碎镜节点-07",
        "端口 8080 存在未认证访问",
    ));
    analyst1.borrow_mut().add(WeaknessReport::new(
        "碎镜节点-12",
        "API 端点泄露内部配置",
    ));

    println!("分析员1 添加了两条报告");

    println!("\n=== 分析员2 添加报告 ===\n");

    // 分析员2 添加报告
    analyst2.borrow_mut().add(WeaknessReport::new(
        "碎镜节点-03",
        "默认密码未修改",
    ));

    println!("分析员2 添加了一条报告");

    println!("\n=== 查看当前所有报告 ===\n");

    // 所有分析员看到的都是同一份数据
    println!("分析员1 看到的列表:");
    for item in analyst1.borrow().list() {
        println!("  {}", item);
    }

    println!("\n分析员2 看到的列表:");
    for item in analyst2.borrow().list() {
        println!("  {}", item);
    }

    println!("\n=== 分析员2 确认报告 ===\n");

    // 分析员2 确认一份报告
    analyst2.borrow_mut().confirm_report("碎镜节点-07");

    println!("分析员2 确认了 '碎镜节点-07'");

    println!("\n=== 确认后所有分析员看到的列表 ===\n");

    println!("分析员1 看到的列表:");
    for item in analyst1.borrow().list() {
        println!("  {}", item);
    }

    println!("\n分析员3 看到的列表:");
    for item in analyst3.borrow().list() {
        println!("  {}", item);
    }

    println!("\n=== 分析员1 删除报告 ===\n");

    // 分析员1 删除一条报告
    analyst1.borrow_mut().remove("碎镜节点-12");

    println!("分析员1 删除了 '碎镜节点-12'");

    println!("\n=== 删除后所有分析员看到的列表 ===\n");

    println!("分析员2 看到的列表:");
    for item in analyst2.borrow().list() {
        println!("  {}", item);
    }

    println!("\n=== 审计日志 ===\n");

    // 查看审计日志
    println!("审计日志 ({} 条记录):", analyst1.borrow().audit_report().len());
    for log in analyst1.borrow().audit_report() {
        println!("  {}", log);
    }

    println!("\n=== 当前引用计数 ===\n");
    println!("当前引用计数: {}", Rc::strong_count(&archive));

    println!("\n=== 安全读取演示 ===\n");

    // 使用 safe_read 安全地读取档案
    let summary = safe_read(&archive, |arch| {
        format!("档案中共有 {} 条报告", arch.reports.len())
    });
    println!("{}", summary);

    // 演示借用冲突（注释掉以免程序崩溃）
    println!("\n=== 借用冲突演示（注释掉） ===\n");
    println!("// 以下代码会触发运行时 panic：");
    println!("// let reader = archive.borrow();");
    println!("// let writer = archive.borrow_mut();  // 运行时崩溃！");
    println!("// 因为读取借用还未释放，不能同时获取可变借用");

    println!("\n=== 程序结束 ===\n");
}