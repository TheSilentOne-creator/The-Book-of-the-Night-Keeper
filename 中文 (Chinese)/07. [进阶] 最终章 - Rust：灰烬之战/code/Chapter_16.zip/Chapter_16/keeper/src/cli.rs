use clap::{Parser, Subcommand};

#[derive(Parser)]
#[command(name = "keeper")]
#[command(about = "沉默者的工具箱 - 火卫一战役指挥系统")]
#[command(version)]
pub struct Cli {
    #[command(subcommand)]
    pub command: Commands,
}

#[derive(Subcommand)]
pub enum Commands {
    /// 爆破扫描：用字典尝试登录接口
    Scan {
        /// 目标登录接口地址
        #[arg(short, long)]
        target: String,

        /// 字典文件路径
        #[arg(short, long)]
        dict: String,

        /// PIN码长度（默认4）
        #[arg(short = 'l', long, default_value_t = 4)]
        pin_length: u32,

        /// 每次尝试之间的延迟（毫秒）
        #[arg(short, long, default_value_t = 0)]
        delay: u64,
    },

    /// 日志分析：从日志文件中提取可疑IP
    Analyze {
        /// 日志文件路径
        #[arg(short, long)]
        log: String,

        /// 可疑阈值（出现次数 ≥ 此值才输出）
        #[arg(short, long, default_value_t = 10)]
        threshold: u32,
    },

    /// 信号塔：启动 HTTP 服务
    Serve {
        /// 监听端口（默认1234）
        #[arg(short, long, default_value_t = 1234)]
        port: u16,
    },
}