use log_hunter::{count_ips, extract_ip, extract_ip_and_path, is_suspicious_path};
use std::collections::HashMap;

// ===== 集成测试 =====

#[test]
fn integration_extract_ip_normal() {
    let line = "192.168.1.10 - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
    assert_eq!(extract_ip(line), Some("192.168.1.10"));
}

#[test]
fn integration_extract_ip_empty() {
    assert_eq!(extract_ip(""), None);
}

#[test]
fn integration_extract_ip_malformed() {
    let line = "not-an-ip - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
    assert_eq!(extract_ip(line), None);
}

#[test]
fn integration_extract_ip_and_path() {
    let line = "10.0.0.5 - - [03/Feb/2025:12:03:42 +0800] \"POST /api/scan HTTP/1.1\" 403";
    assert_eq!(extract_ip_and_path(line), Some(("10.0.0.5", "/api/scan")));
}

#[test]
fn integration_is_suspicious_path() {
    assert!(is_suspicious_path("/login"));
    assert!(is_suspicious_path("/api/scan"));
    assert!(is_suspicious_path("/admin"));
    assert!(!is_suspicious_path("/index.html"));
    assert!(!is_suspicious_path("/style.css"));
}

#[test]
fn integration_count_ips() {
    let lines = vec![
        String::from("192.168.1.10 GET /login 200"),
        String::from("10.0.0.5 POST /api/scan 403"),
        String::from("192.168.1.10 GET /index.html 200"),
        String::from("172.16.0.8 GET /admin 200"),
    ];
    let counts = count_ips(&lines);
    assert_eq!(counts.get("192.168.1.10"), Some(&2));
    assert_eq!(counts.get("10.0.0.5"), Some(&1));
    assert_eq!(counts.get("172.16.0.8"), Some(&1));
    assert_eq!(counts.get("10.0.0.1"), None);
}

#[test]
fn integration_count_ips_with_duplicates() {
    let lines = vec![
        String::from("10.0.0.5 POST /login 200"),
        String::from("10.0.0.5 POST /api/scan 403"),
        String::from("10.0.0.5 GET /admin 200"),
        String::from("10.0.0.5 GET /index.html 200"),
        String::from("10.0.0.5 GET /style.css 200"),
        String::from("10.0.0.5 GET /favicon.ico 200"),
    ];
    let counts = count_ips(&lines);
    assert_eq!(counts.get("10.0.0.5"), Some(&6));
}

#[test]
fn integration_count_ips_empty_input() {
    let lines: Vec<String> = Vec::new();
    let counts = count_ips(&lines);
    assert!(counts.is_empty());
    assert_eq!(counts.len(), 0);
}

#[test]
fn integration_count_ips_no_valid_ips() {
    let lines = vec![
        String::from("[03/Feb/2025:12:03:42 +0800]"),
        String::from(""),
        String::from("abc"),
        String::from("not-an-ip - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200"),
    ];
    let counts = count_ips(&lines);
    assert!(counts.is_empty());
}

#[test]
fn integration_extract_ip_with_private_ips() {
    let lines = vec![
        "192.168.1.10 - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200",
        "10.0.0.5 - - [03/Feb/2025:12:03:42 +0800] \"POST /api/scan HTTP/1.1\" 403",
        "172.16.0.8 - - [03/Feb/2025:12:10:55 +0800] \"GET /config HTTP/1.1\" 404",
    ];
    for line in lines {
        assert!(extract_ip(line).is_some());
    }
}