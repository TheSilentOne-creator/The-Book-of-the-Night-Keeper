use std::collections::HashMap;

// ===== 核心函数 =====

/// 从日志行中提取 IP 地址。
///
/// 只有当第一个片段看起来像 IP 地址（由点分隔的四段数字）时，才返回 Some(ip)。
/// 否则返回 None。
///
/// # Examples
///
/// ```
/// use log_hunter::extract_ip;
///
/// let line = "192.168.1.10 - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
/// assert_eq!(extract_ip(line), Some("192.168.1.10"));
///
/// let empty = "";
/// assert_eq!(extract_ip(empty), None);
/// ```
pub fn extract_ip(line: &str) -> Option<&str> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.is_empty() {
        return None;
    }
    let first = parts[0];
    let segments: Vec<&str> = first.split('.').collect();
    if segments.len() == 4 && segments.iter().all(|s| s.chars().all(|c| c.is_digit(10))) {
        Some(first)
    } else {
        None
    }
}

/// 从日志行中提取 IP 地址和请求路径。
///
/// 只有当行格式正确（至少 7 个字段）且方法为 GET 或 POST 时，才返回 Some((ip, path))。
pub fn extract_ip_and_path(line: &str) -> Option<(&str, &str)> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.len() < 7 {
        return None;
    }
    let ip = parts[0];
    let method = parts[5];
    let path = parts[6];
    if method == "GET" || method == "POST" {
        Some((ip, path))
    } else {
        None
    }
}

/// 判断路径是否为可疑路径。
///
/// 可疑路径包括：/login、/api/scan、/admin
pub fn is_suspicious_path(path: &str) -> bool {
    path == "/login" || path == "/api/scan" || path == "/admin"
}

/// 统计日志中每个 IP 的出现次数。
///
/// # Examples
///
/// ```
/// use log_hunter::count_ips;
/// use std::collections::HashMap;
///
/// let lines = vec![
///     String::from("192.168.1.10 GET /login 200"),
///     String::from("10.0.0.5 POST /api/scan 403"),
///     String::from("192.168.1.10 GET /index.html 200"),
/// ];
/// let counts = count_ips(&lines);
/// assert_eq!(counts.get("192.168.1.10"), Some(&2));
/// assert_eq!(counts.get("10.0.0.5"), Some(&1));
/// ```
pub fn count_ips(lines: &[String]) -> HashMap<String, u32> {
    let mut counts = HashMap::new();
    for line in lines {
        if let Some(ip) = extract_ip(line) {
            let ip_string = ip.to_string();
            *counts.entry(ip_string).or_insert(0) += 1;
        }
    }
    counts
}

// ===== 单元测试 =====

#[cfg(test)]
mod tests {
    use super::*;

    // ---------- extract_ip 测试 ----------

    #[test]
    fn extract_ip_normal() {
        let line = "192.168.1.10 - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
        assert_eq!(extract_ip(line), Some("192.168.1.10"));
    }

    #[test]
    fn extract_ip_empty_line() {
        assert_eq!(extract_ip(""), None);
    }

    #[test]
    fn extract_ip_no_ip() {
        let line = "[03/Feb/2025:12:03:42 +0800]";
        assert_eq!(extract_ip(line), None);
    }

    #[test]
    fn extract_ip_malformed_ip() {
        let line = "999.999.999.999 - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
        // 虽然每段数字都在 0-255 之外，但 is_digit 仍然为 true
        // 这个测试应该通过，因为我们的检查不验证每段的范围
        assert_eq!(extract_ip(line), Some("999.999.999.999"));
    }

    #[test]
    fn extract_ip_invalid_format() {
        let line = "not-an-ip - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
        assert_eq!(extract_ip(line), None);
    }

    #[test]
    fn extract_ip_private_ip() {
        let line = "10.0.0.5 - - [03/Feb/2025:12:03:42 +0800] \"POST /api/scan HTTP/1.1\" 403";
        assert_eq!(extract_ip(line), Some("10.0.0.5"));
    }

    // ---------- extract_ip_and_path 测试 ----------

    #[test]
    fn extract_ip_and_path_normal() {
        let line = "192.168.1.10 - - [03/Feb/2025:12:01:17 +0800] \"GET /login HTTP/1.1\" 200";
        assert_eq!(extract_ip_and_path(line), Some(("192.168.1.10", "/login")));
    }

    #[test]
    fn extract_ip_and_path_short_line() {
        let line = "192.168.1.10 GET /login 200";
        assert_eq!(extract_ip_and_path(line), None);
    }

    #[test]
    fn extract_ip_and_path_empty_line() {
        assert_eq!(extract_ip_and_path(""), None);
    }

    // ---------- is_suspicious_path 测试 ----------

    #[test]
    fn is_suspicious_path_login() {
        assert!(is_suspicious_path("/login"));
    }

    #[test]
    fn is_suspicious_path_api_scan() {
        assert!(is_suspicious_path("/api/scan"));
    }

    #[test]
    fn is_suspicious_path_admin() {
        assert!(is_suspicious_path("/admin"));
    }

    #[test]
    fn is_suspicious_path_normal() {
        assert!(!is_suspicious_path("/index.html"));
    }

    #[test]
    fn is_suspicious_path_style_css() {
        assert!(!is_suspicious_path("/style.css"));
    }

    #[test]
    fn is_suspicious_path_favicon() {
        assert!(!is_suspicious_path("/favicon.ico"));
    }

    // ---------- count_ips 测试 ----------

    #[test]
    fn count_ips_empty() {
        let lines: Vec<String> = Vec::new();
        let counts = count_ips(&lines);
        assert!(counts.is_empty());
    }

    #[test]
    fn count_ips_normal() {
        let lines = vec![
            String::from("192.168.1.10 GET /login 200"),
            String::from("10.0.0.5 POST /api/scan 403"),
            String::from("192.168.1.10 GET /index.html 200"),
        ];
        let counts = count_ips(&lines);
        assert_eq!(counts.get("192.168.1.10"), Some(&2));
        assert_eq!(counts.get("10.0.0.5"), Some(&1));
        assert_eq!(counts.get("172.16.0.8"), None);
    }

    #[test]
    fn count_ips_duplicate() {
        let lines = vec![
            String::from("10.0.0.5 POST /login 200"),
            String::from("10.0.0.5 POST /api/scan 403"),
            String::from("10.0.0.5 GET /admin 200"),
            String::from("10.0.0.5 GET /index.html 200"),
        ];
        let counts = count_ips(&lines);
        assert_eq!(counts.get("10.0.0.5"), Some(&4));
    }

    #[test]
    fn count_ips_no_ip() {
        let lines = vec![
            String::from("[03/Feb/2025:12:03:42 +0800]"),
            String::from(""),
            String::from("abc"),
        ];
        let counts = count_ips(&lines);
        assert!(counts.is_empty());
    }

    #[test]
    fn count_ips_mixed() {
        let lines = vec![
            String::from("192.168.1.10 GET /login 200"),
            String::from("[03/Feb/2025:12:03:42 +0800]"),
            String::from("10.0.0.5 POST /api/scan 403"),
            String::from(""),
            String::from("172.16.0.8 GET /admin 200"),
            String::from("abc"),
        ];
        let counts = count_ips(&lines);
        assert_eq!(counts.get("192.168.1.10"), Some(&1));
        assert_eq!(counts.get("10.0.0.5"), Some(&1));
        assert_eq!(counts.get("172.16.0.8"), Some(&1));
        assert_eq!(counts.len(), 3);
    }
}