use std::collections::HashMap;

fn main() {
    // ===== 模拟数据流 =====
    let logs = vec![
        "192.168.1.10 GET /login 200",
        "10.0.0.5 POST /api/scan 403",
        "192.168.1.10 GET /index.html 200",
        "10.0.0.5 POST /login 200",
        "172.16.0.8 GET /config 404",
        "10.0.0.5 POST /api/scan 403",
        "192.168.1.10 GET /admin 200",
        "10.0.0.5 POST /login 200",
        "10.0.0.5 POST /api/scan 403",
        "10.0.0.5 POST /api/scan 403",
    ];

    // ===== 闭包演示 =====
    println!("=== 闭包演示 ===");

    // 闭包捕获环境变量
    let threshold = 3;
    let is_high_risk = |count: u32| count >= threshold;
    println!("阈值: {}，5次攻击是否高危: {}", threshold, is_high_risk(5));
    println!("阈值: {}，2次攻击是否高危: {}", threshold, is_high_risk(2));

    // move 闭包演示
    let name = String::from("守夜者");
    let take_name = move || {
        println!("{} 发动攻击！", name);
    };
    take_name();
    // println!("{}", name);  // 编译错误！name 已被 move 进闭包

    // ===== 迭代器链演示 =====
    println!("\n=== 迭代器链演示 ===");

    // 1. 基础 map + collect
    let numbers = vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    let doubled: Vec<_> = numbers.iter().map(|x| x * 2).collect();
    println!("原始: {:?}", numbers);
    println!("翻倍: {:?}", doubled);

    // 2. filter + map
    let filtered: Vec<_> = numbers
        .iter()
        .filter(|&x| x > 5)
        .map(|x| x * 2)
        .collect();
    println!("大于5且翻倍: {:?}", filtered);

    // 3. filter_map（过滤 + 转换一步完成）
    let raw = vec![Some(10), None, Some(20), None, Some(30)];
    let cleaned: Vec<_> = raw.into_iter().filter_map(|x| x).collect();
    println!("filter_map 清理 None: {:?}", cleaned);

    // ===== 日志分析实战 =====
    println!("\n=== 日志分析实战 ===");

    // 第一步：提取可疑请求（POST /login 或 POST /api/scan）
    let suspicious: Vec<_> = logs
        .iter()
        .filter_map(|line| {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() >= 3 {
                Some((parts[0], parts[1], parts[2]))
            } else {
                None
            }
        })
        .filter(|(ip, method, path)| {
            *method == "POST" && (*path == "/login" || *path == "/api/scan")
        })
        .map(|(ip, _, path)| (ip, path))
        .collect();

    println!("可疑请求:");
    for (ip, path) in &suspicious {
        println!("  {} -> {}", ip, path);
    }

    // 第二步：用 fold 统计每个可疑 IP 的攻击次数
    let counts = suspicious
        .iter()
        .fold(HashMap::new(), |mut acc, (ip, _)| {
            *acc.entry(*ip).or_insert(0) += 1;
            acc
        });

    println!("\n可疑IP统计 (fold):");
    for (ip, count) in &counts {
        println!("  {}: {} 次", ip, count);
    }

    // 第三步：filter 只保留高危 IP
    let high_risk: HashMap<_, _> = counts
        .iter()
        .filter(|(_, &count)| count >= 3)
        .map(|(&ip, &count)| (ip, count))
        .collect();

    println!("\n高危IP (>=3次):");
    for (ip, count) in &high_risk {
        println!("  {}: {} 次", ip, count);
    }

    // ===== sum 演示 =====
    println!("\n=== sum 演示 ===");
    let sum: i32 = (1..=100).sum();
    println!("1到100的和: {}", sum);

    // ===== count 演示 =====
    let count_even: usize = (1..=20).filter(|x| x % 2 == 0).count();
    println!("1到20中的偶数个数: {}", count_even);

    // ===== 链式调用综合 =====
    println!("\n=== 综合链式调用 ===");
    let result: Vec<_> = (1..=50)
        .filter(|x| x % 2 == 0)
        .map(|x| x * 3)
        .filter(|x| x > 30)
        .take(5)
        .collect();

    println!("1-50的偶数*3，大于30，取前5个:");
    println!("  {:?}", result);
}