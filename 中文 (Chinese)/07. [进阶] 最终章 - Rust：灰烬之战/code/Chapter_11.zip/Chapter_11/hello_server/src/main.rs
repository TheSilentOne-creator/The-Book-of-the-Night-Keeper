use std::io::{BufRead, BufReader, Write};
use std::net::TcpListener;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let listener = TcpListener::bind("127.0.0.1:7878")?;
    println!("守夜者已经站岗: http://127.0.0.1:7878");

    for stream in listener.incoming() {
        let mut stream = stream?;
        let reader = BufReader::new(&stream);

        let request_line = match reader.lines().next() {
            Some(Ok(line)) => line,
            _ => continue,
        };

        println!("收到请求: {}", request_line);

        let response = "HTTP/1.1 200 OK\r\nContent-Length: 18\r\n\r\n守夜者，我在。";
        stream.write_all(response.as_bytes())?;
        stream.flush()?;
    }

    Ok(())
}