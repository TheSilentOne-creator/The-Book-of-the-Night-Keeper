use std::fs;
use std::io::{self, BufRead};

pub fn load_dict(path: &str, pin_length: u32) -> Result<Vec<String>, String> {
    let file = match fs::File::open(path) {
        Ok(f) => f,
        Err(e) => {
            return Err(format!("打不开字典文件 '{}': {}", path, e));
        }
    };

    let reader = io::BufReader::new(file);

    let mut pins = Vec::new();
    let mut total_lines = 0;
    let mut empty_lines = 0;
    let mut bad_lines = 0;
    let mut bad_examples: Vec<String> = Vec::new();

    for line in reader.lines() {
        total_lines += 1;

        let line = match line {
            Ok(l) => l,
            Err(e) => {
                eprintln!("警告：第 {} 行读不了，跳过。原因: {}", total_lines, e);
                continue;
            }
        };

        let pin = line.trim().to_string();

        if pin.is_empty() {
            empty_lines += 1;
            continue;
        }

        if pin.len() != pin_length as usize {
            bad_lines += 1;
            if bad_examples.len() < 5 {
                bad_examples.push(format!("'{}' ({}位)", pin, pin.len()));
            }
            continue;
        }

        if !pin.chars().all(|c| c.is_digit(10)) {
            bad_lines += 1;
            if bad_examples.len() < 5 {
                let non_digit: String = pin
                    .chars()
                    .filter(|c| !c.is_digit(10))
                    .collect();
                bad_examples.push(format!("'{}' (含非数字字符: '{}')", pin, non_digit));
            }
            continue;
        }

        pins.push(pin);
    }

    if pins.is_empty() {
        return Err(format!(
            "字典文件 '{}' 里一个有效 PIN 码都没有！\n\
             总行数: {}，空行: {}，无效行: {}",
            path, total_lines, empty_lines, bad_lines
        ));
    }

    eprintln!("--- 字典加载报告 ---");
    eprintln!(
        "文件: {} | 总行: {} | 有效: {} | 空行: {} | 无效: {}",
        path, total_lines, pins.len(), empty_lines, bad_lines
    );
    if bad_lines > 0 {
        for example in &bad_examples {
            eprintln!("  例: {}", example);
        }
    }
    eprintln!("---");

    Ok(pins)
}