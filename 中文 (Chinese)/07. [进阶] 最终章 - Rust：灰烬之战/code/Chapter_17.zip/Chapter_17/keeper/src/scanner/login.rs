use reqwest::blocking::Client;

pub fn try_login(
    client: &Client,
    pin: &str,
    target: &str,
) -> Result<bool, reqwest::Error> {
    let response = client
        .post(target)
        .header("Content-Type", "application/json")
        .json(&serde_json::json!({ "pin": pin }))
        .send()?;

    Ok(response.status().is_success())
}