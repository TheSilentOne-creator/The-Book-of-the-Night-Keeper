use std::collections::HashMap;

use super::extract::{extract_ip, extract_ip_and_path, is_suspicious_path};

pub fn count_ips(lines: &[String]) -> HashMap<String, u32> {
    let mut counts = HashMap::new();

    for line in lines {
        if let Some(ip) = extract_ip(line) {
            let ip_string = ip.to_string();
            *counts.entry(ip_string).or_insert(0) += 1;
        }
    }

    counts
}

pub fn find_suspicious_ips(lines: &[String], threshold: u32) -> HashMap<String, u32> {
    let mut counts = HashMap::new();

    for line in lines {
        if let Some((ip, path)) = extract_ip_and_path(line) {
            if is_suspicious_path(path) {
                let ip_string = ip.to_string();
                *counts.entry(ip_string).or_insert(0) += 1;
            }
        }
    }

    counts.retain(|_, count| *count >= threshold);
    counts
}

pub fn sort_counts(counts: &HashMap<String, u32>) -> Vec<(&String, &u32)> {
    let mut sorted: Vec<(&String, &u32)> = counts.iter().collect();
    sorted.sort_by(|a, b| b.1.cmp(a.1));
    sorted
}