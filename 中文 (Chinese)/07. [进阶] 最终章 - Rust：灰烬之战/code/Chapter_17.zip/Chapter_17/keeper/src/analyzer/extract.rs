pub fn extract_ip(line: &str) -> Option<&str> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.is_empty() {
        return None;
    }

    let first = parts[0];
    let segments: Vec<&str> = first.split('.').collect();

    if segments.len() == 4 && segments.iter().all(|s| s.chars().all(|c| c.is_digit(10))) {
        Some(first)
    } else {
        None
    }
}

pub fn extract_ip_and_path(line: &str) -> Option<(&str, &str)> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.len() < 7 {
        return None;
    }

    let ip = parts[0];
    let method = parts[5];
    let path = parts[6];

    if method == "GET" || method == "POST" {
        Some((ip, path))
    } else {
        None
    }
}

pub fn is_suspicious_path(path: &str) -> bool {
    path == "/login" || path == "/api/scan" || path == "/admin" || path == "/config"
}