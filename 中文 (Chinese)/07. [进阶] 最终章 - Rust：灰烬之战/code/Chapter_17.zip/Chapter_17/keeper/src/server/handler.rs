use std::io::{BufRead, BufReader, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::{Arc, Mutex, mpsc};
use std::thread;

type Job = Box<dyn FnOnce() + Send + 'static>;

struct ThreadPool {
    workers: Vec<Worker>,
    sender: mpsc::Sender<Job>,
}

impl ThreadPool {
    fn new(size: usize) -> ThreadPool {
        let (sender, receiver) = mpsc::channel();
        let receiver = Arc::new(Mutex::new(receiver));

        let mut workers = Vec::with_capacity(size);
        for id in 0..size {
            workers.push(Worker::new(id, Arc::clone(&receiver)));
        }

        ThreadPool { workers, sender }
    }

    fn execute<F>(&self, f: F)
    where
        F: FnOnce() + Send + 'static,
    {
        let job = Box::new(f);
        self.sender.send(job).unwrap();
    }
}

struct Worker {
    id: usize,
    thread: thread::JoinHandle<()>,
}

impl Worker {
    fn new(id: usize, receiver: Arc<Mutex<mpsc::Receiver<Job>>>) -> Worker {
        let thread = thread::spawn(move || loop {
            let job = receiver.lock().unwrap().recv();

            match job {
                Ok(job) => {
                    println!("Worker {} 开始执行任务", id);
                    job();
                }
                Err(_) => {
                    println!("Worker {} 收到关闭信号，退出", id);
                    break;
                }
            }
        });

        Worker { id, thread }
    }
}

fn handle_connection(mut stream: TcpStream) {
    let reader = BufReader::new(&stream);

    let request_line = match reader.lines().next() {
        Some(Ok(line)) => line,
        _ => return,
    };

    println!("收到请求: {}", request_line);

    let path = request_line
        .split_whitespace()
        .nth(1)
        .unwrap_or("/");

    let (status_line, body) = match path {
        "/" => ("HTTP/1.1 200 OK", "守夜者，我在。"),
        "/status" => ("HTTP/1.1 200 OK", "Status: alive."),
        _ => ("HTTP/1.1 404 NOT FOUND", "Not found."),
    };

    let response = format!(
        "{}\r\nContent-Length: {}\r\n\r\n{}\r\n",
        status_line,
        body.len(),
        body
    );

    let _ = stream.write_all(response.as_bytes());
    let _ = stream.flush();
}

pub fn run_server(port: u16) -> Result<(), Box<dyn std::error::Error>> {
    let addr = format!("127.0.0.1:{}", port);
    let listener = TcpListener::bind(&addr)?;
    let pool = ThreadPool::new(4);

    println!("守夜者已经站岗: http://{}", addr);

    for stream in listener.incoming() {
        let stream = stream?;
        pool.execute(move || {
            handle_connection(stream);
        });
    }

    Ok(())
}