use reqwest::blocking::Client;

use crate::scanner::{load_dict, try_login};

pub fn run(
    target: &str,
    dict_path: &str,
    pin_length: u32,
    delay: u64,
) -> Result<(), Box<dyn std::error::Error>> {
    let client = Client::new();
    let pins = load_dict(dict_path, pin_length)?;

    println!("目标: {}", target);
    println!("字典: {}", dict_path);
    println!("字典加载完成，共 {} 个密码，开始爆破...", pins.len());

    for (i, pin) in pins.iter().enumerate() {
        print!("[{}] 正在尝试: {} ... ", i + 1, pin);

        match try_login(&client, pin, target) {
            Ok(true) => {
                println!(">>> 门开了！正确的 PIN 码是: {} <<<", pin);
                return Ok(());
            }
            Ok(false) => println!("错。继续。"),
            Err(e) => println!("网络炸了: {}，跳过这个继续下一个。", e),
        }

        if delay > 0 {
            std::thread::sleep(std::time::Duration::from_millis(delay));
        }
    }

    println!("爆破完成，未找到正确的 PIN 码。");
    Ok(())
}