use crate::server::run_server;

pub fn run(port: u16) -> Result<(), Box<dyn std::error::Error>> {
    run_server(port)
}