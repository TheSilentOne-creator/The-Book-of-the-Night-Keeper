use std::fs::File;
use std::io::{BufRead, BufReader};

use crate::analyzer::{find_suspicious_ips, sort_counts};

pub fn run(log_path: &str, threshold: u32) -> Result<(), Box<dyn std::error::Error>> {
    let file = File::open(log_path)?;
    let reader = BufReader::new(file);

    let mut lines = Vec::new();
    for line in reader.lines() {
        lines.push(line?);
    }

    let suspicious = find_suspicious_ips(&lines, threshold);
    let sorted = sort_counts(&suspicious);

    if sorted.is_empty() {
        println!("没有发现可疑IP（阈值: {}）", threshold);
    } else {
        println!("=== 可疑IP列表 ===");
        for (ip, count) in sorted {
            println!("{} → {} 次攻击", ip, count);
        }
    }

    Ok(())
}