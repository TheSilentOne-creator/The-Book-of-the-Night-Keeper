use std::fs;
use std::path::Path;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

use reqwest::blocking::Client;
use serde_json::json;

#[derive(serde::Serialize)]
struct Legacy {
    tool_hash: String,
    version: String,
    git_commit: String,
    summary: String,
    timestamp: String,
}

pub fn run(target_dir: &str) -> Result<(), Box<dyn std::error::Error>> {
    println!("🔥 火卫一战役——自毁与永恒");

    // 第一步：刻入永恒
    if let Err(e) = immortalize() {
        eprintln!("⚠️ 永恒刻录失败: {}", e);
        eprintln!("继续执行自毁...");
    }

    // 第二步：自毁
    self_destruct(target_dir)?;

    println!();
    println!("✅ 火卫一流程完成。");
    println!("  你的成果已刻入永恒。");
    println!("  你的痕迹已被清除。");
    println!("  灰烬落在地上，长出新东西。");

    Ok(())
}

fn immortalize() -> Result<(), Box<dyn std::error::Error>> {
    println!("🌐 正在将核心成果刻入永恒...");

    // 1. 计算当前工具的哈希
    let exe_path = std::env::current_exe()?;
    let content = fs::read(&exe_path)?;
    let hash = sha256::digest(&content);
    println!("  工具哈希: {}", hash);

    // 2. 获取 Git 提交哈希
    let git_commit = get_git_commit()?;
    println!("  Git 提交: {}", git_commit);

    // 3. 构建存证数据
    let legacy = Legacy {
        tool_hash: hash,
        version: env!("CARGO_PKG_VERSION").to_string(),
        git_commit,
        summary: String::from(
            "守夜者工具箱 - 包含爆破扫描、日志分析、信号塔三大模块。\
             扫描模块：字典爆破4-6位PIN码，支持延迟和最大尝试次数。\
             日志分析模块：从攻击日志中提取可疑IP，按路径过滤。\
             信号塔模块：多线程HTTP服务器，支持路由。",
        ),
        timestamp: current_timestamp(),
    };

    // 4. 上传到区块链服务
    let client = Client::new();
    let response = client
        .post("https://api.example.com/immortalize")
        .json(&json!({ "legacy": legacy }))
        .send();

    match response {
        Ok(resp) => {
            if resp.status().is_success() {
                let tx_id = resp.text().unwrap_or_default();
                println!("✅ 成果已刻入永恒！交易ID: {}", tx_id);
                println!("  今后的守夜者可以在区块链上看到你的足迹。");
            } else {
                println!("⚠️ 上传失败，状态码: {}", resp.status());
            }
        }
        Err(e) => {
            println!("⚠️ 上传失败，请检查网络连接。错误: {}", e);
        }
    }

    Ok(())
}

fn self_destruct(target_dir: &str) -> Result<(), Box<dyn std::error::Error>> {
    println!("🔥 开始自毁程序...");

    let path = Path::new(target_dir);

    if !path.exists() {
        println!("目标路径不存在，跳过。");
        return Ok(());
    }

    // 删除各类痕迹文件
    let extensions = vec!["log", "tmp", "toml", "json", "txt"];
    for ext in extensions {
        let count = delete_files_with_extension(path, ext)?;
        if count > 0 {
            println!("  删除了 {} 个 .{} 文件", count, ext);
        }
    }

    // 删除自身
    if let Ok(exe_path) = std::env::current_exe() {
        println!("  删除自身: {}", exe_path.display());
        if let Err(e) = fs::remove_file(&exe_path) {
            println!("  无法删除自身: {}（可能正在运行）", e);
        }
    }

    // 尝试删除目标目录
    if let Ok(entries) = fs::read_dir(path) {
        let count = entries.count();
        if count == 0 {
            if let Ok(()) = fs::remove_dir(path) {
                println!("  删除了空目录: {}", path.display());
            }
        } else {
            println!("  目录不为空，保留: {}", path.display());
        }
    }

    println!("✅ 自毁完成。火卫一上不会有我们的痕迹。");
    Ok(())
}

fn delete_files_with_extension(
    dir: &Path,
    ext: &str,
) -> Result<usize, Box<dyn std::error::Error>> {
    let mut count = 0;

    if !dir.exists() {
        return Ok(0);
    }

    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let file_path = entry.path();

        if !file_path.is_file() {
            continue;
        }

        let should_delete = file_path
            .extension()
            .and_then(|e| e.to_str())
            .map(|e| e == ext)
            .unwrap_or(false);

        if should_delete {
            fs::remove_file(&file_path)?;
            count += 1;
        }
    }

    Ok(count)
}

fn get_git_commit() -> Result<String, Box<dyn std::error::Error>> {
    let output = Command::new("git")
        .args(["rev-parse", "HEAD"])
        .output()?;

    if output.status.success() {
        let commit = String::from_utf8(output.stdout)?;
        Ok(commit.trim().to_string())
    } else {
        Ok("unknown".to_string())
    }
}

fn current_timestamp() -> String {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();

    format!("Unix时间戳: {} 秒", now.as_secs())
}