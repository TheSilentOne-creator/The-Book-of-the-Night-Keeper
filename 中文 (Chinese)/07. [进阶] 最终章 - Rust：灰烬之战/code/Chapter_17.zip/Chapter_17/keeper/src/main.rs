use clap::Parser;

use keeper::cli::{Cli, Commands};
use keeper::commands::{analyze, firefall, scan, serve};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let cli = Cli::parse();

    match cli.command {
        Commands::Scan {
            target,
            dict,
            pin_length,
            delay,
        } => {
            scan::run(&target, &dict, pin_length, delay)?;
        }
        Commands::Analyze { log, threshold } => {
            analyze::run(&log, threshold)?;
        }
        Commands::Serve { port } => {
            serve::run(port)?;
        }
        Commands::Firefall { target } => {
            firefall::run(&target)?;
        }
    }

    Ok(())
}