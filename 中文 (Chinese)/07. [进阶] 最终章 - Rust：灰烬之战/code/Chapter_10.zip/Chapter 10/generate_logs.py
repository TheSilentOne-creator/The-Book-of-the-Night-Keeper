#!/usr/bin/env python3
"""
随机日志生成器
用法: python generate_logs.py [行数] [输出文件名]
示例: python generate_logs.py 5000 attacks.log
"""

# 生成默认 3000 行
# python generate_logs.py

# 生成 5000 行
# python generate_logs.py 5000

# 生成 10000 行，保存到 attacks.log
# python generate_logs.py 10000 attacks.log

import random
import sys
from datetime import datetime, timedelta

# 正常路径
NORMAL_PATHS = [
    "/index.html", "/favicon.ico", "/about", "/contact",
    "/css/style.css", "/js/app.js", "/images/logo.png",
    "/api/status", "/api/health", "/api/version",
]

# 可疑路径（爆破/扫描特征）
SUSPICIOUS_PATHS = [
    "/login", "/admin", "/api/scan", "/api/upload",
    "/config", "/backup", "/db", "/shell",
]

# IP 池（混合正常IP和可疑IP）
NORMAL_IPS = [
    "192.168.1.10", "192.168.1.20", "192.168.1.30",
    "172.16.0.5", "172.16.0.10", "172.16.0.15",
    "10.0.0.10", "10.0.0.20", "10.0.0.30",
]

SUSPICIOUS_IPS = [
    "10.0.0.5",      # 爆破主力
    "192.168.1.100", # 扫描器
    "172.16.0.200",  # 渗透测试
]

# 状态码
NORMAL_STATUS = [200, 304, 404]
SUSPICIOUS_STATUS = [200, 401, 403, 404, 500]

# HTTP 方法
METHODS = ["GET", "POST", "PUT", "DELETE"]


def random_time(start_date, end_date):
    """生成两个日期之间的随机时间"""
    delta = end_date - start_date
    random_seconds = random.randint(0, int(delta.total_seconds()))
    return start_date + timedelta(seconds=random_seconds)


def generate_log_line():
    """生成单行日志"""
    # 随机时间（2026年1月1日 - 2026年12月31日）
    start = datetime(2026, 1, 1, 0, 0, 0)
    end = datetime(2026, 12, 31, 23, 59, 59)
    timestamp = random_time(start, end)
    time_str = timestamp.strftime("%d/%b/%Y:%H:%M:%S +0800")

    # 随机IP（7/10概率用正常IP，3/10概率用可疑IP）
    if random.random() < 0.7:
        ip = random.choice(NORMAL_IPS)
        status = random.choice(NORMAL_STATUS)
    else:
        ip = random.choice(SUSPICIOUS_IPS)
        status = random.choice(SUSPICIOUS_STATUS)

    # 随机路径（7/10概率正常，3/10概率可疑）
    if random.random() < 0.7:
        path = random.choice(NORMAL_PATHS)
    else:
        path = random.choice(SUSPICIOUS_PATHS)

    method = random.choice(METHODS)

    return f'{ip} - - [{time_str}] "{method} {path} HTTP/1.1" {status}'


def generate_logs(num_lines=3000, output_file="attacks.log"):
    """生成日志文件"""
    with open(output_file, "w", encoding="utf-8") as f:
        for _ in range(num_lines):
            f.write(generate_log_line() + "\n")

    print(f"✅ 已生成 {num_lines} 行日志，保存到: {output_file}")
    print("   - 包含正常访问和可疑攻击混合数据")
    print("   - 可疑IP: 10.0.0.5, 192.168.1.100, 172.16.0.200")
    print("   - 可疑路径: /login, /admin, /api/scan, /config, /backup")


if __name__ == "__main__":
    # 从命令行读取参数
    if len(sys.argv) >= 2:
        try:
            num_lines = int(sys.argv[1])
        except ValueError:
            print("❌ 行数必须是整数")
            sys.exit(1)
    else:
        num_lines = 3000

    if len(sys.argv) >= 3:
        output_file = sys.argv[2]
    else:
        output_file = "attacks.log"

    generate_logs(num_lines, output_file)