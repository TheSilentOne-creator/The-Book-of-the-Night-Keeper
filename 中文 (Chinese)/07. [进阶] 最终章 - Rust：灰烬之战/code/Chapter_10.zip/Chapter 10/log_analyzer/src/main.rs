use std::collections::HashMap;
use std::fs::File;
use std::io::{BufRead, BufReader};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let file = File::open("attacks.log")?;
    let reader = BufReader::new(file);

    let mut lines = Vec::new();
    for line in reader.lines() {
        lines.push(line?);
    }

    let suspicious = find_suspicious_ips(&lines, 10);
    let sorted = sort_counts(&suspicious);

    for (ip, count) in sorted {
        println!("{} → {} 次攻击", ip, count);
    }

    Ok(())
}

#[allow(dead_code)]
fn extract_ip(line: &str) -> Option<&str> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.is_empty() {
        return None;
    }
    Some(parts[0])
}

fn extract_ip_and_path(line: &str) -> Option<(&str, &str)> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.len() < 7 {
        return None;
    }

    let ip = parts[0];
    let method = parts[5];
    let path = parts[6];

    if method == "GET" || method == "POST" {
        Some((ip, path))
    } else {
        None
    }
}

fn is_suspicious_path(path: &str) -> bool {
    path == "/login" || path == "/api/scan" || path == "/admin"
}

#[allow(dead_code)]
fn count_ips(lines: &[String]) -> HashMap<String, u32> {
    let mut counts = HashMap::new();

    for line in lines {
        if let Some(ip) = extract_ip(line) {
            let ip_string = ip.to_string();
            *counts.entry(ip_string).or_insert(0) += 1;
        }
    }

    counts
}

fn find_suspicious_ips(lines: &[String], threshold: u32) -> HashMap<String, u32> {
    let mut counts = HashMap::new();

    for line in lines {
        if let Some((ip, path)) = extract_ip_and_path(line) {
            if is_suspicious_path(path) {
                let ip_string = ip.to_string();
                *counts.entry(ip_string).or_insert(0) += 1;
            }
        }
    }

    counts.retain(|_, count| *count >= threshold);
    counts
}

fn sort_counts(counts: &HashMap<String, u32>) -> Vec<(&String, &u32)> {
    let mut sorted: Vec<(&String, &u32)> = counts.iter().collect();
    sorted.sort_by(|a, b| b.1.cmp(a.1));
    sorted
}